var APromise = {};

APromise.all = function(promises){};

APromise.race = function(promises){};

APromise.resolve = function(value){};

APromise.reject = function(err){};

module.exports.APromise = APromise;
