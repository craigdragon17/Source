function mapAsync(iterator, obj, context) {};
function mapAsyncInOrder(iterator, array, context) {};
function mapAsyncInDescendingOrder(iterator, array, context) {};